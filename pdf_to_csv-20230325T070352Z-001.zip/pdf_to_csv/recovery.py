
import os
import tabula

# specify the path of the PDF files
pdf_folder = "C:/Users/SAMSON/Desktop/BIA/pdf_to_csv"

# specify the path of the CSV output folder
csv_folder = "C:/Users/SAMSON/Desktop/BIA/pdf_to_csv/RESULT"

# loop through all the PDF files in the folder
for filename in os.listdir(pdf_folder):
    if filename.endswith(".pdf"):
        # specify the input file path
        input_path = os.path.join(pdf_folder, filename)
        
        # specify the output file path
        output_path = os.path.join(csv_folder, os.path.splitext(filename)[0] + ".csv")
        
        # convert the PDF file to CSV
        tabula.convert_into(input_path, output_path, output_format="csv", pages="all")



